document.getElementById('button').addEventListener('click',function(){
    document.querySelector('body').style.backgroundColor = 'skyblue';
})